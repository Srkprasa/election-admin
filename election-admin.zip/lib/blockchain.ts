// Simple blockchain implementation for election voting
export type Block = {
  index: number
  timestamp: number
  votes: Vote[]
  previousHash: string
  hash: string
  nonce: number
}

export type Vote = {
  electionId: string
  candidateId: string
  voterId: string // Encrypted or hashed voter ID
  timestamp: number
  zkProof: string // Zero-knowledge proof
}

export class Blockchain {
  private chain: Block[]
  private currentVotes: Vote[]
  private difficulty: number

  constructor() {
    this.chain = [this.createGenesisBlock()]
    this.currentVotes = []
    this.difficulty = 2 // Adjust difficulty as needed
  }

  private createGenesisBlock(): Block {
    return {
      index: 0,
      timestamp: Date.now(),
      votes: [],
      previousHash: "0",
      hash: "0",
      nonce: 0,
    }
  }

  getLatestBlock(): Block {
    return this.chain[this.chain.length - 1]
  }

  // Add a vote to the pending votes
  addVote(vote: Omit<Vote, "timestamp">): void {
    this.currentVotes.push({
      ...vote,
      timestamp: Date.now(),
    })
  }

  // Mine a new block (called periodically or when enough votes are collected)
  mineBlock(): Block {
    if (this.currentVotes.length === 0) {
      throw new Error("No votes to mine")
    }

    const block = {
      index: this.chain.length,
      timestamp: Date.now(),
      votes: [...this.currentVotes],
      previousHash: this.getLatestBlock().hash,
      hash: "",
      nonce: 0,
    }

    block.hash = this.calculateHash(block)
    const newBlock = this.proofOfWork(block)

    this.chain.push(newBlock)
    this.currentVotes = []

    return newBlock
  }

  // Simple proof of work algorithm
  private proofOfWork(block: Block): Block {
    const target = Array(this.difficulty + 1).join("0")
    const newBlock = { ...block }

    while (newBlock.hash.substring(0, this.difficulty) !== target) {
      newBlock.nonce++
      newBlock.hash = this.calculateHash(newBlock)
    }

    return newBlock
  }

  // Calculate hash using block data
  private calculateHash(block: Block): string {
    const blockData = block.index + block.previousHash + block.timestamp + JSON.stringify(block.votes) + block.nonce
    return this.sha256(blockData)
  }

  // Simple SHA-256 implementation (in a real app, use a proper crypto library)
  private sha256(data: string): string {
    // This is a placeholder - in a real app, use a proper crypto library
    let hash = 0
    for (let i = 0; i < data.length; i++) {
      const char = data.charCodeAt(i)
      hash = (hash << 5) - hash + char
      hash = hash & hash
    }
    return hash.toString(16).padStart(64, "0")
  }

  // Validate the blockchain
  isChainValid(): boolean {
    for (let i = 1; i < this.chain.length; i++) {
      const currentBlock = this.chain[i]
      const previousBlock = this.chain[i - 1]

      // Validate hash
      if (currentBlock.hash !== this.calculateHash(currentBlock)) {
        return false
      }

      // Validate previous hash reference
      if (currentBlock.previousHash !== previousBlock.hash) {
        return false
      }
    }
    return true
  }

  // Get all votes for a specific election
  getVotesForElection(electionId: string): Vote[] {
    const votes: Vote[] = []

    for (const block of this.chain) {
      for (const vote of block.votes) {
        if (vote.electionId === electionId) {
          votes.push(vote)
        }
      }
    }

    return votes
  }

  // Get the entire blockchain
  getChain(): Block[] {
    return this.chain
  }
}

// Create a singleton instance
export const blockchain = new Blockchain()

