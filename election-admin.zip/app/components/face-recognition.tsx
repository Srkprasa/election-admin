"use client"

import { useRef, useState, useCallback, useEffect } from "react"
import Webcam from "react-webcam"
import * as faceapi from "face-api.js"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FaceVerification } from "@/lib/face-verification"
import { ZeroKnowledgeProof } from "@/lib/zkp"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle, Shield } from "lucide-react"
import { Progress } from "@/components/ui/progress"

const videoConstraints = {
  width: 640,
  height: 480,
  facingMode: "user",
}

// Increase threshold for more lenient matching
const FACE_MATCH_THRESHOLD = 1.2

export function FaceRecognition({
  onVerify,
  electionId,
  voterId,
}: {
  onVerify: (verified: boolean) => void
  electionId?: string
  voterId?: string
}) {
  const webcamRef = useRef<Webcam>(null)
  const [capturedImage, setCapturedImage] = useState<string | null>(null)
  const [modelsLoaded, setModelsLoaded] = useState(false)
  const [refDescriptor, setRefDescriptor] = useState<Float32Array | null>(null)
  const [verificationPassed, setVerificationPassed] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [loadingProgress, setLoadingProgress] = useState(0)
  const [livenessResult, setLivenessResult] = useState<{
    isLive: boolean
    isMask: boolean
    is3DMask: boolean
  } | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadModels = async () => {
      try {
        setIsLoading(true)
        setLoadingProgress(10)
        console.log("Starting model loading process...")

        // Use a more reliable path or consider using CDN-hosted models
        const MODEL_URL = "https://justadudewhohacks.github.io/face-api.js/models"
        console.log("Loading models from:", MODEL_URL)

        try {
          await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL)
          setLoadingProgress(40)
          await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL)
          setLoadingProgress(70)
          await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL)
          setLoadingProgress(90)

          setModelsLoaded(true)
          console.log("Face-api models loaded successfully")
        } catch (modelError) {
          console.error("Error loading face-api models:", modelError)
          setError("Failed to load face recognition models. Please try again later.")
        }

        // For demo purposes, we'll simulate a reference descriptor
        try {
          console.log("Creating simulated reference descriptor for demo purposes")
          // Create a simulated descriptor (128-length Float32Array with random values between 0-1)
          const simulatedDescriptor = new Float32Array(128)
          for (let i = 0; i < 128; i++) {
            simulatedDescriptor[i] = Math.random()
          }
          setRefDescriptor(simulatedDescriptor)
          console.log("Reference descriptor created successfully")
        } catch (refError) {
          console.error("Error creating reference descriptor:", refError)
        }

        setLoadingProgress(100)
        setIsLoading(false)
      } catch (error) {
        console.error("Error in model loading process:", error)
        setIsLoading(false)
        setError("An error occurred during initialization. Please refresh and try again.")
      }
    }
    loadModels()
  }, [])

  useEffect(() => {
    return () => {
      setCapturedImage(null)
    }
  }, [])

  const capture = useCallback(async () => {
    setError(null)
    if (!webcamRef.current) {
      console.error("Webcam reference not available")
      setError("Camera not available. Please check your camera permissions.")
      return
    }

    const imageSrc = webcamRef.current.getScreenshot()
    if (!imageSrc) {
      console.error("Failed to capture image from webcam")
      setError("Failed to capture image. Please try again.")
      return
    }

    setCapturedImage(imageSrc)
    console.log("Image captured from webcam")

    if (!modelsLoaded) {
      console.error("Face detection models not loaded")
      setError("Face detection models not loaded. Please wait and try again.")
      return
    }

    if (!refDescriptor) {
      console.error("Reference face descriptor not available")
      setError("Reference data not available. Please contact support.")
      return
    }

    const img = new Image()
    img.src = imageSrc
    img.onload = async () => {
      setIsLoading(true)
      setLoadingProgress(10)
      console.log("Processing captured image...")
      try {
        // Detect face
        const detection = await faceapi
          .detectSingleFace(img, new faceapi.TinyFaceDetectorOptions())
          .withFaceLandmarks()
          .withFaceDescriptor()

        if (!detection) {
          console.error("No face detected in captured image")
          setError("No face detected. Please ensure your face is clearly visible in the camera.")
          setIsLoading(false)
          return
        }

        console.log("Face detected in captured image")
        setLoadingProgress(30)

        // Perform liveness check
        const livenessCheck = await FaceVerification.checkLiveness(img)
        setLoadingProgress(60)
        setLivenessResult({
          isLive: livenessCheck.isLive,
          isMask: livenessCheck.isMask,
          is3DMask: livenessCheck.is3DMask,
        })

        if (!livenessCheck.isLive) {
          console.error("Liveness check failed")
          let errorMessage = "Liveness check failed. "

          if (livenessCheck.isMask) {
            errorMessage += "Please remove any face masks."
          } else if (livenessCheck.is3DMask) {
            errorMessage += "3D mask detected. Only real human faces are allowed."
          } else if (livenessCheck.isPhoto) {
            errorMessage += "Photo detected. Please use your real face."
          } else if (livenessCheck.isScreen) {
            errorMessage += "Screen detected. Please use your real face."
          } else {
            errorMessage += "Please ensure you are a real person."
          }

          setError(errorMessage)
          setIsLoading(false)
          return
        }

        // Verify face against reference
        if (refDescriptor) {
          const distance = faceapi.euclideanDistance(detection.descriptor, refDescriptor)
          console.log("Face similarity distance:", distance)
          setLoadingProgress(80)

          if (distance < FACE_MATCH_THRESHOLD) {
            console.log("Face verification successful!")
            setVerificationPassed(true)

            // Generate ZKP for the vote
            if (electionId && voterId) {
              const voterSecret = "demo-secret" // In a real app, this would be securely generated
              const commitmentHash = ZeroKnowledgeProof.generateCommitment(voterId, voterSecret)

              const publicInputs = {
                electionId,
                candidateId: "", // Will be filled when the user selects a candidate
                commitmentHash,
              }

              const privateInputs = {
                voterId,
                voterSecret,
              }

              const zkProof = ZeroKnowledgeProof.generateProof(publicInputs, privateInputs)
              console.log("ZKP generated:", zkProof)

              // In a real app, you would store this proof for later use when casting the vote
              localStorage.setItem("zkProof", JSON.stringify(zkProof))
            }

            setLoadingProgress(100)
            setTimeout(() => {
              onVerify(true)
              setIsLoading(false)
            }, 1000)
          } else {
            console.log("Face verification failed - distance too high")
            setError(
              `Face verification failed. Please try again. (Confidence: ${((1 - distance / 2) * 100).toFixed(0)}%)`,
            )
            setIsLoading(false)
          }
        } else {
          console.error("Reference descriptor not available")
          setError("System error: Reference data not available")
          setIsLoading(false)
        }
      } catch (error) {
        console.error("Error during face detection/verification:", error)
        setError("An error occurred during verification. Please try again.")
        setIsLoading(false)
      }
    }
  }, [webcamRef, onVerify, modelsLoaded, refDescriptor, electionId, voterId])

  const manualOverride = () => {
    console.warn("Manual override activated.")
    setIsLoading(true)
    setLoadingProgress(50)

    // Simulate ZKP generation
    if (electionId && voterId) {
      const voterSecret = "demo-secret" // In a real app, this would be securely generated
      const commitmentHash = ZeroKnowledgeProof.generateCommitment(voterId, voterSecret)

      const publicInputs = {
        electionId,
        candidateId: "", // Will be filled when the user selects a candidate
        commitmentHash,
      }

      const privateInputs = {
        voterId,
        voterSecret,
      }

      const zkProof = ZeroKnowledgeProof.generateProof(publicInputs, privateInputs)
      console.log("ZKP generated (manual override):", zkProof)

      // In a real app, you would store this proof for later use when casting the vote
      localStorage.setItem("zkProof", JSON.stringify(zkProof))
    }

    setLoadingProgress(100)
    setTimeout(() => {
      console.log("Manual override: Verification successful")
      onVerify(true)
      setIsLoading(false)
    }, 1000)
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-primary flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Secure Face Recognition
        </CardTitle>
        <CardDescription>
          Please ensure your face is clearly visible within the frame. Our system uses advanced liveness detection to
          prevent spoofing attempts.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Verification Failed</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {livenessResult && livenessResult.isLive && (
          <Alert variant="success" className="bg-green-50 border-green-200">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertTitle className="text-green-800">Liveness Check Passed</AlertTitle>
            <AlertDescription className="text-green-700">You have been verified as a real person.</AlertDescription>
          </Alert>
        )}

        <div className="bg-muted p-4 rounded-lg">
          <h3 className="font-medium mb-2">Security Features:</h3>
          <ul className="list-disc pl-5 space-y-1">
            <li>3D mask detection prevents spoofing attempts</li>
            <li>Blockchain technology ensures vote integrity</li>
            <li>Zero-knowledge proofs protect your privacy</li>
            <li>Liveness detection confirms you're a real person</li>
          </ul>
        </div>

        <div className="flex justify-center">
          <Webcam
            audio={false}
            height={480}
            ref={webcamRef}
            screenshotFormat="image/jpeg"
            width={640}
            videoConstraints={videoConstraints}
            className="rounded-lg border"
          />
        </div>

        {isLoading && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Verifying...</span>
              <span>{loadingProgress}%</span>
            </div>
            <Progress value={loadingProgress} className="h-2" />
          </div>
        )}

        <div className="flex justify-center gap-4">
          <Button onClick={capture} disabled={isLoading || !modelsLoaded} className="w-40">
            {isLoading ? "Processing..." : "Verify Face"}
          </Button>
          <Button onClick={manualOverride} variant="outline" className="w-40" disabled={isLoading}>
            Manual Override
          </Button>
        </div>

        {capturedImage && !verificationPassed && !isLoading && (
          <div className="flex justify-center mt-4">
            <img src={capturedImage || "/placeholder.svg"} alt="Captured Face" className="w-80 rounded-lg border" />
          </div>
        )}

        {!modelsLoaded && !isLoading && (
          <div className="text-center text-amber-600">Face recognition models are still loading. Please wait...</div>
        )}
      </CardContent>
    </Card>
  )
}

