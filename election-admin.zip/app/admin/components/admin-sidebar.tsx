"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { BarChart3, CalendarDays, Home, ListChecks, LogOut, Settings, Users } from "lucide-react"

const sidebarItems = [
  {
    title: "Dashboard",
    href: "/admin",
    icon: Home,
  },
  {
    title: "Elections",
    href: "/admin/elections",
    icon: CalendarDays,
  },
  {
    title: "Candidates",
    href: "/admin/candidates",
    icon: Users,
  },
  {
    title: "Results",
    href: "/admin/results",
    icon: BarChart3,
  },
  {
    title: "Voters",
    href: "/admin/voters",
    icon: ListChecks,
  },
  {
    title: "Settings",
    href: "/admin/settings",
    icon: Settings,
  },
]

export default function AdminSidebar() {
  const pathname = usePathname()

  return (
    <div className="flex flex-col border-r bg-muted/40 h-full">
      <div className="p-6">
        <Link href="/">
          <h2 className="text-lg font-semibold">Admin Portal</h2>
        </Link>
      </div>
      <div className="flex-1 px-4">
        <nav className="flex flex-col gap-2">
          {sidebarItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <Button
                variant="ghost"
                className={cn("w-full justify-start gap-2", pathname === item.href && "bg-muted")}
              >
                <item.icon className="h-4 w-4" />
                {item.title}
              </Button>
            </Link>
          ))}
        </nav>
      </div>
      <div className="p-4 mt-auto">
        <Link href="/">
          <Button variant="outline" className="w-full justify-start gap-2">
            <LogOut className="h-4 w-4" />
            Exit Admin
          </Button>
        </Link>
      </div>
    </div>
  )
}

