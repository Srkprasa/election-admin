import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Download, Eye } from "lucide-react"
import Link from "next/link"

export default function ResultsPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Election Results</h1>
          <p className="text-muted-foreground">View and manage election results</p>
        </div>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader className="flex flex-row items-start justify-between">
            <div>
              <CardTitle>Student Council Election</CardTitle>
              <CardDescription>
                <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800 mt-1">
                  Active
                </span>
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" disabled>
                <Eye className="mr-2 h-4 w-4" />
                Results Not Available
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Start Date</p>
                  <p className="text-sm">May 1, 2023</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">End Date</p>
                  <p className="text-sm">May 15, 2023</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Votes</p>
                  <p className="text-sm">87 (ongoing)</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <p className="text-sm">Results will be available after election ends</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-start justify-between">
            <div>
              <CardTitle>Department Head Election</CardTitle>
              <CardDescription>
                <span className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800 mt-1">
                  Completed
                </span>
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Link href="/admin/results/2">
                <Button variant="outline">
                  <Eye className="mr-2 h-4 w-4" />
                  View Results
                </Button>
              </Link>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Start Date</p>
                  <p className="text-sm">Apr 1, 2023</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">End Date</p>
                  <p className="text-sm">Apr 10, 2023</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Votes</p>
                  <p className="text-sm">76</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Winner</p>
                  <p className="text-sm">Michael Brown (Engineering)</p>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium mb-2">Results Summary</h3>
                <div className="space-y-2">
                  <div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Michael Brown</span>
                      <span>58%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full mt-1">
                      <div className="h-full bg-primary rounded-full" style={{ width: "58%" }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Jennifer Lee</span>
                      <span>42%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full mt-1">
                      <div className="h-full bg-primary rounded-full" style={{ width: "42%" }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-start justify-between">
            <div>
              <CardTitle>Faculty Senate Election</CardTitle>
              <CardDescription>
                <span className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800 mt-1">
                  Completed
                </span>
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Link href="/admin/results/3">
                <Button variant="outline">
                  <Eye className="mr-2 h-4 w-4" />
                  View Results
                </Button>
              </Link>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Start Date</p>
                  <p className="text-sm">Mar 10, 2023</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">End Date</p>
                  <p className="text-sm">Mar 22, 2023</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Votes</p>
                  <p className="text-sm">85</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Winners</p>
                  <p className="text-sm">5 elected representatives</p>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium mb-2">Results Summary</h3>
                <div className="space-y-2">
                  <div>
                    <div className="flex items-center justify-between text-sm">
                      <span>David Wilson</span>
                      <span>24%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full mt-1">
                      <div className="h-full bg-primary rounded-full" style={{ width: "24%" }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Maria Garcia</span>
                      <span>22%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full mt-1">
                      <div className="h-full bg-primary rounded-full" style={{ width: "22%" }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Robert Chen</span>
                      <span>18%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full mt-1">
                      <div className="h-full bg-primary rounded-full" style={{ width: "18%" }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

