import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Edit, Plus, Trash2 } from "lucide-react"
import Link from "next/link"

export default function ElectionsPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Elections</h1>
          <p className="text-muted-foreground">Create and manage elections</p>
        </div>
        <Link href="/admin/elections/create">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Create Election
          </Button>
        </Link>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader className="flex flex-row items-start justify-between">
            <div>
              <CardTitle>Student Council Election</CardTitle>
              <CardDescription>
                <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800 mt-1">
                  Active
                </span>
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Link href="/admin/elections/1/edit">
                <Button variant="outline" size="icon">
                  <Edit className="h-4 w-4" />
                </Button>
              </Link>
              <Button variant="outline" size="icon">
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Start Date</p>
                  <p className="text-sm">May 1, 2023</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">End Date</p>
                  <p className="text-sm">May 15, 2023</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Positions</p>
                  <p className="text-sm">President, Vice President, Secretary</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Candidates</p>
                  <p className="text-sm">6</p>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Link href="/admin/elections/1/candidates">
                  <Button variant="outline" size="sm">
                    Manage Candidates
                  </Button>
                </Link>
                <Link href="/admin/elections/1">
                  <Button size="sm">View Details</Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-start justify-between">
            <div>
              <CardTitle>Department Head Election</CardTitle>
              <CardDescription>
                <span className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800 mt-1">
                  Completed
                </span>
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Link href="/admin/elections/2/edit">
                <Button variant="outline" size="icon">
                  <Edit className="h-4 w-4" />
                </Button>
              </Link>
              <Button variant="outline" size="icon">
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Start Date</p>
                  <p className="text-sm">Apr 1, 2023</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">End Date</p>
                  <p className="text-sm">Apr 10, 2023</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Positions</p>
                  <p className="text-sm">Department Head (Engineering, Science, Arts)</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Candidates</p>
                  <p className="text-sm">4</p>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Link href="/admin/elections/2/candidates">
                  <Button variant="outline" size="sm">
                    Manage Candidates
                  </Button>
                </Link>
                <Link href="/admin/elections/2">
                  <Button size="sm">View Details</Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-start justify-between">
            <div>
              <CardTitle>Faculty Senate Election</CardTitle>
              <CardDescription>
                <span className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800 mt-1">
                  Completed
                </span>
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Link href="/admin/elections/3/edit">
                <Button variant="outline" size="icon">
                  <Edit className="h-4 w-4" />
                </Button>
              </Link>
              <Button variant="outline" size="icon">
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Start Date</p>
                  <p className="text-sm">Mar 10, 2023</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">End Date</p>
                  <p className="text-sm">Mar 22, 2023</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Positions</p>
                  <p className="text-sm">Faculty Senate Representatives (5 positions)</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Candidates</p>
                  <p className="text-sm">8</p>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Link href="/admin/elections/3/candidates">
                  <Button variant="outline" size="sm">
                    Manage Candidates
                  </Button>
                </Link>
                <Link href="/admin/elections/3">
                  <Button size="sm">View Details</Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

