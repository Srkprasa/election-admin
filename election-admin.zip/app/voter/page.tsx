"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { FaceRecognition } from "../components/face-recognition"
import { CheckCircle2, Shield, Vote } from "lucide-react"
import Link from "next/link"
import { blockchain } from "@/lib/blockchain"
import { ZeroKnowledgeProof } from "@/lib/zkp"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function VoterPage() {
  const [step, setStep] = useState<"welcome" | "verification" | "voting" | "confirmation">("welcome")
  const [isVerified, setIsVerified] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [selectedCandidates, setSelectedCandidates] = useState<Record<string, string>>({})
  const [votingError, setVotingError] = useState<string | null>(null)

  // Mock election and voter data
  const electionId = "election-123"
  const voterId = "voter-456"

  const handleVerification = (verified: boolean) => {
    setIsLoading(false)
    setIsVerified(verified)
    if (verified) {
      setStep("voting")
    }
  }

  const handleCandidateSelection = (position: string, candidateId: string) => {
    setSelectedCandidates({
      ...selectedCandidates,
      [position]: candidateId,
    })
  }

  const handleVote = () => {
    setVotingError(null)
    setIsLoading(true)

    try {
      // Check if all positions have a selected candidate
      const positions = ["president", "vicePresident", "secretary"]
      const allSelected = positions.every((position) => selectedCandidates[position])

      if (!allSelected) {
        setVotingError("Please select a candidate for each position.")
        setIsLoading(false)
        return
      }

      // Get the ZKP from localStorage (in a real app, this would be more secure)
      const zkProofString = localStorage.getItem("zkProof")
      if (!zkProofString) {
        setVotingError("Verification data not found. Please verify your identity again.")
        setIsLoading(false)
        return
      }

      const zkProof = JSON.parse(zkProofString)

      // Record votes on the blockchain
      for (const position of positions) {
        const candidateId = selectedCandidates[position]

        // Update the ZKP with the specific candidate
        const updatedPublicInputs = {
          ...zkProof.publicInputs,
          candidateId,
        }

        // Verify the proof
        const isValid = ZeroKnowledgeProof.verifyProof({
          ...zkProof,
          publicInputs: updatedPublicInputs,
        })

        if (!isValid) {
          setVotingError("Vote verification failed. Please try again.")
          setIsLoading(false)
          return
        }

        // Add the vote to the blockchain
        blockchain.addVote({
          electionId,
          candidateId,
          voterId: zkProof.publicInputs.commitmentHash, // Use the commitment hash instead of actual voter ID
          zkProof: zkProof.proof,
        })
      }

      // Mine the block to record the votes
      try {
        const newBlock = blockchain.mineBlock()
        console.log("Votes recorded in block:", newBlock)
      } catch (error) {
        console.error("Error mining block:", error)
      }

      // Clear the ZKP from localStorage
      localStorage.removeItem("zkProof")

      // Move to confirmation step
      setTimeout(() => {
        setIsLoading(false)
        setStep("confirmation")
      }, 1500)
    } catch (error) {
      console.error("Error during voting:", error)
      setVotingError("An error occurred while recording your vote. Please try again.")
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-muted/40">
      <header className="bg-primary text-primary-foreground p-4">
        <div className="container mx-auto">
          <h1 className="text-2xl font-bold">Election Management System</h1>
        </div>
      </header>

      <main className="container mx-auto py-8 px-4">
        {step === "welcome" && (
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="text-2xl">Welcome to the Secure Voting Portal</CardTitle>
              <CardDescription>You are about to participate in the Student Council Election</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                Before you can vote, we need to verify your identity using our secure facial recognition system. This
                ensures the integrity of our election process.
              </p>
              <p>Please make sure you are in a well-lit area and your face is clearly visible.</p>
              <div className="bg-muted p-4 rounded-lg">
                <h3 className="font-medium mb-2">Security Features:</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>
                    <span className="font-medium">Blockchain Technology:</span> Your vote is securely recorded on a
                    blockchain, ensuring it cannot be altered or deleted.
                  </li>
                  <li>
                    <span className="font-medium">Zero-Knowledge Proofs:</span> Your identity remains private while
                    still verifying your eligibility to vote.
                  </li>
                  <li>
                    <span className="font-medium">Anti-Spoofing Protection:</span> Our system can detect 3D masks and
                    other spoofing attempts.
                  </li>
                  <li>
                    <span className="font-medium">Liveness Detection:</span> Ensures only real humans can vote, not
                    photos or recordings.
                  </li>
                </ul>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={() => setStep("verification")} className="w-full">
                <Shield className="mr-2 h-4 w-4" />
                Begin Secure Verification
              </Button>
            </CardFooter>
          </Card>
        )}

        {step === "verification" && (
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold">Secure Identity Verification</h2>
              <p className="text-muted-foreground">Please complete the face verification process to continue</p>
            </div>

            <FaceRecognition onVerify={handleVerification} electionId={electionId} voterId={voterId} />

            <div className="flex justify-center">
              <Button variant="outline" onClick={() => setStep("welcome")} disabled={isLoading}>
                Back
              </Button>
            </div>
          </div>
        )}

        {step === "voting" && (
          <div className="space-y-6 max-w-4xl mx-auto">
            <div className="text-center">
              <h2 className="text-2xl font-bold">Cast Your Secure Vote</h2>
              <p className="text-muted-foreground">Select your preferred candidates for each position</p>
            </div>

            {votingError && (
              <Alert variant="destructive">
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{votingError}</AlertDescription>
              </Alert>
            )}

            <Card>
              <CardHeader>
                <CardTitle>President</CardTitle>
                <CardDescription>Select one candidate for President</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4">
                  <label className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-muted/50">
                    <input
                      type="radio"
                      name="president"
                      className="h-5 w-5"
                      onChange={() => handleCandidateSelection("president", "candidate-1")}
                    />
                    <div>
                      <p className="font-medium">John Smith</p>
                      <p className="text-sm text-muted-foreground">Computer Science Department</p>
                    </div>
                  </label>
                  <label className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-muted/50">
                    <input
                      type="radio"
                      name="president"
                      className="h-5 w-5"
                      onChange={() => handleCandidateSelection("president", "candidate-2")}
                    />
                    <div>
                      <p className="font-medium">Emily Johnson</p>
                      <p className="text-sm text-muted-foreground">Business Administration Department</p>
                    </div>
                  </label>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Vice President</CardTitle>
                <CardDescription>Select one candidate for Vice President</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4">
                  <label className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-muted/50">
                    <input
                      type="radio"
                      name="vicePresident"
                      className="h-5 w-5"
                      onChange={() => handleCandidateSelection("vicePresident", "candidate-3")}
                    />
                    <div>
                      <p className="font-medium">Sarah Johnson</p>
                      <p className="text-sm text-muted-foreground">Business Administration Department</p>
                    </div>
                  </label>
                  <label className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-muted/50">
                    <input
                      type="radio"
                      name="vicePresident"
                      className="h-5 w-5"
                      onChange={() => handleCandidateSelection("vicePresident", "candidate-4")}
                    />
                    <div>
                      <p className="font-medium">Michael Brown</p>
                      <p className="text-sm text-muted-foreground">Engineering Department</p>
                    </div>
                  </label>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Secretary</CardTitle>
                <CardDescription>Select one candidate for Secretary</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4">
                  <label className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-muted/50">
                    <input
                      type="radio"
                      name="secretary"
                      className="h-5 w-5"
                      onChange={() => handleCandidateSelection("secretary", "candidate-5")}
                    />
                    <div>
                      <p className="font-medium">David Wilson</p>
                      <p className="text-sm text-muted-foreground">Arts Department</p>
                    </div>
                  </label>
                  <label className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-muted/50">
                    <input
                      type="radio"
                      name="secretary"
                      className="h-5 w-5"
                      onChange={() => handleCandidateSelection("secretary", "candidate-6")}
                    />
                    <div>
                      <p className="font-medium">Jessica Lee</p>
                      <p className="text-sm text-muted-foreground">Science Department</p>
                    </div>
                  </label>
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setStep("verification")}>
                Back
              </Button>
              <Button onClick={handleVote} disabled={isLoading}>
                {isLoading ? (
                  "Recording Vote..."
                ) : (
                  <>
                    <Vote className="mr-2 h-4 w-4" />
                    Submit Secure Vote
                  </>
                )}
              </Button>
            </div>
          </div>
        )}

        {step === "confirmation" && (
          <Card className="max-w-md mx-auto">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <CheckCircle2 className="h-16 w-16 text-green-500" />
              </div>
              <CardTitle className="text-2xl">Vote Securely Recorded!</CardTitle>
              <CardDescription>Your vote has been secured on the blockchain</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-center">
                  Your vote has been recorded securely using blockchain technology. The results will be published after
                  the election period ends.
                </p>
                <div className="bg-muted p-4 rounded-lg">
                  <h3 className="font-medium mb-2">Security Confirmation:</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Your vote is immutably recorded on the blockchain</li>
                    <li>Your identity remains private through zero-knowledge proofs</li>
                    <li>Your vote cannot be altered or deleted</li>
                    <li>The election results will be cryptographically verified</li>
                  </ul>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Link href="/">
                <Button>Return to Home</Button>
              </Link>
            </CardFooter>
          </Card>
        )}
      </main>

      <footer className="bg-muted p-4 text-center mt-auto">
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} Secure Election Management System. All rights reserved.
        </p>
      </footer>
    </div>
  )
}

