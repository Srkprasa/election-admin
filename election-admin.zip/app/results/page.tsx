"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Download, Lock } from "lucide-react"
import { blockchain } from "@/lib/blockchain"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

// Type for election data
type Election = {
  id: string
  title: string
  description: string
  startDate: Date
  endDate: Date
  isActive: boolean
  positions: {
    name: string
    candidates: {
      id: string
      name: string
      department: string
      votes: number
    }[]
  }[]
  totalVotes: number
}

export default function PublicResultsPage() {
  const [elections, setElections] = useState<Election[]>([])
  const [loading, setLoading] = useState(true)
  const [currentDate] = useState(new Date())

  // Fetch elections that are relevant for today's date
  useEffect(() => {
    const fetchElections = async () => {
      try {
        // In a real app, this would be an API call to your backend
        // For this demo, we'll create mock data

        // Get the current date without time
        const today = new Date()
        today.setHours(0, 0, 0, 0)

        // Mock elections data
        const mockElections: Election[] = [
          {
            id: "election-1",
            title: "Student Council Election",
            description: "Election for student council positions",
            startDate: new Date(today.getTime() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
            endDate: new Date(today.getTime() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
            isActive: true,
            positions: [
              {
                name: "President",
                candidates: [
                  { id: "candidate-1", name: "John Smith", department: "Computer Science", votes: 45 },
                  { id: "candidate-2", name: "Emily Johnson", department: "Business", votes: 32 },
                ],
              },
              {
                name: "Vice President",
                candidates: [
                  { id: "candidate-3", name: "Sarah Johnson", department: "Business", votes: 38 },
                  { id: "candidate-4", name: "Michael Brown", department: "Engineering", votes: 39 },
                ],
              },
            ],
            totalVotes: 87,
          },
          {
            id: "election-2",
            title: "Department Head Election",
            description: "Election for department heads",
            startDate: new Date(today.getTime() - 15 * 24 * 60 * 60 * 1000), // 15 days ago
            endDate: new Date(today.getTime() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
            isActive: false,
            positions: [
              {
                name: "Engineering Department Head",
                candidates: [
                  { id: "candidate-5", name: "Michael Brown", department: "Engineering", votes: 44 },
                  { id: "candidate-6", name: "Jennifer Lee", department: "Engineering", votes: 32 },
                ],
              },
              {
                name: "Science Department Head",
                candidates: [
                  { id: "candidate-7", name: "Robert Chen", department: "Science", votes: 49 },
                  { id: "candidate-8", name: "Sarah Williams", department: "Science", votes: 27 },
                ],
              },
            ],
            totalVotes: 76,
          },
          {
            id: "election-3",
            title: "Faculty Senate Election",
            description: "Election for faculty senate representatives",
            startDate: new Date(today.getTime() - 25 * 24 * 60 * 60 * 1000), // 25 days ago
            endDate: new Date(today.getTime() - 15 * 24 * 60 * 60 * 1000), // 15 days ago
            isActive: false,
            positions: [
              {
                name: "Faculty Senate Representatives",
                candidates: [
                  { id: "candidate-9", name: "David Wilson", department: "Arts", votes: 20 },
                  { id: "candidate-10", name: "Maria Garcia", department: "Languages", votes: 19 },
                  { id: "candidate-11", name: "Robert Chen", department: "Science", votes: 15 },
                  { id: "candidate-12", name: "Lisa Thompson", department: "History", votes: 13 },
                  { id: "candidate-13", name: "James Rodriguez", department: "Mathematics", votes: 10 },
                  { id: "candidate-14", name: "Emily Davis", department: "Psychology", votes: 8 },
                ],
              },
            ],
            totalVotes: 85,
          },
        ]

        // Filter elections that are relevant for today
        // For active elections, show them but hide results
        // For completed elections, show results
        const relevantElections = mockElections.filter((election) => {
          // Show active elections (current date is between start and end date)
          if (election.startDate <= today && today <= election.endDate) {
            return true
          }

          // Show completed elections (end date has passed)
          if (today > election.endDate) {
            return true
          }

          return false
        })

        setElections(relevantElections)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching elections:", error)
        setLoading(false)
      }
    }

    fetchElections()
  }, [])

  // Function to check if an election's results should be visible
  const shouldShowResults = (election: Election) => {
    return !election.isActive
  }

  // Function to get votes from blockchain (in a real app)
  const getVotesFromBlockchain = (electionId: string) => {
    try {
      // Get votes from blockchain
      const votes = blockchain.getVotesForElection(electionId)
      console.log(`Retrieved ${votes.length} votes for election ${electionId} from blockchain`)
      return votes
    } catch (error) {
      console.error("Error getting votes from blockchain:", error)
      return []
    }
  }

  return (
    <div className="min-h-screen bg-muted/40">
      <header className="bg-primary text-primary-foreground p-4">
        <div className="container mx-auto">
          <h1 className="text-2xl font-bold">Election Management System</h1>
        </div>
      </header>

      <main className="container mx-auto py-8 px-4">
        <div className="max-w-4xl mx-auto space-y-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Election Results</h1>
            <p className="text-muted-foreground">View the results of completed elections</p>
          </div>

          {loading ? (
            <div className="text-center py-8">
              <p>Loading election results...</p>
            </div>
          ) : elections.length === 0 ? (
            <Alert>
              <AlertTitle>No Elections Found</AlertTitle>
              <AlertDescription>There are no elections available to display at this time.</AlertDescription>
            </Alert>
          ) : (
            elections.map((election) => (
              <Card key={election.id}>
                <CardHeader className="flex flex-row items-start justify-between">
                  <div>
                    <CardTitle>{election.title}</CardTitle>
                    <CardDescription>
                      {election.isActive ? (
                        <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800 mt-1">
                          Active
                        </span>
                      ) : (
                        <span className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800 mt-1">
                          Completed
                        </span>
                      )}
                    </CardDescription>
                  </div>
                  {!election.isActive && (
                    <Button variant="outline" size="sm">
                      <Download className="mr-2 h-4 w-4" />
                      Download Results
                    </Button>
                  )}
                </CardHeader>
                <CardContent>
                  {election.isActive ? (
                    <div className="text-center py-8">
                      <Lock className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <p className="text-lg font-medium">
                        Results will be available after {election.endDate.toLocaleDateString()}
                      </p>
                      <p className="text-muted-foreground">
                        The election is currently in progress. Check back after the election ends.
                      </p>
                      <div className="mt-4">
                        <p className="text-sm font-medium text-muted-foreground">Current Participation</p>
                        <p className="text-sm">{election.totalVotes} votes cast so far</p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">Election Period</p>
                          <p className="text-sm">
                            {election.startDate.toLocaleDateString()} - {election.endDate.toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">Total Votes</p>
                          <p className="text-sm">{election.totalVotes}</p>
                        </div>
                      </div>

                      {election.positions.map((position) => (
                        <div
                          key={position.name}
                          className={position.name !== election.positions[0].name ? "pt-4 border-t" : ""}
                        >
                          <h3 className="text-lg font-medium mb-4">{position.name}</h3>
                          <div className="space-y-4">
                            {position.candidates
                              .sort((a, b) => b.votes - a.votes)
                              .map((candidate, index) => {
                                const percentage = Math.round((candidate.votes / election.totalVotes) * 100)
                                const isWinner = index === 0

                                return (
                                  <div key={candidate.id}>
                                    <div className="flex items-center justify-between mb-1">
                                      <div className="flex items-center">
                                        <div
                                          className={`h-3 w-3 rounded-full ${isWinner ? "bg-primary" : "bg-blue-400"} mr-2`}
                                        ></div>
                                        <span className="font-medium">
                                          {candidate.name}
                                          {isWinner && (
                                            <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded-full">
                                              Winner
                                            </span>
                                          )}
                                        </span>
                                      </div>
                                      <span>
                                        {percentage}% ({candidate.votes} votes)
                                      </span>
                                    </div>
                                    <div className="h-4 bg-muted rounded-full">
                                      <div
                                        className={`h-full ${isWinner ? "bg-primary" : "bg-blue-400"} rounded-full`}
                                        style={{ width: `${percentage}%` }}
                                      ></div>
                                    </div>
                                  </div>
                                )
                              })}
                          </div>
                        </div>
                      ))}

                      <div className="pt-4 border-t">
                        <h3 className="text-sm font-medium mb-2">Blockchain Verification</h3>
                        <p className="text-sm text-muted-foreground">
                          These results are cryptographically verified and immutably stored on the blockchain. Each vote
                          can be independently verified without revealing voter identities.
                        </p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </main>

      <footer className="bg-muted p-4 text-center mt-auto">
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} Election Management System. All rights reserved.
        </p>
      </footer>
    </div>
  )
}

