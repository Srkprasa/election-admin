import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-primary text-primary-foreground p-4">
        <div className="container mx-auto">
          <h1 className="text-2xl font-bold">Election Management System</h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto p-4 md:p-8">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 my-8">
          <div className="bg-card text-card-foreground rounded-lg border shadow-sm p-6">
            <h2 className="text-xl font-semibold mb-4">Admin Portal</h2>
            <p className="text-muted-foreground mb-4">Create and manage elections, add candidates, and view results.</p>
            <Link href="/admin">
              <Button>Access Admin Portal</Button>
            </Link>
          </div>

          <div className="bg-card text-card-foreground rounded-lg border shadow-sm p-6">
            <h2 className="text-xl font-semibold mb-4">Voter Portal</h2>
            <p className="text-muted-foreground mb-4">
              Verify your identity with face recognition and cast your vote securely.
            </p>
            <Link href="/voter">
              <Button variant="outline">Access Voter Portal</Button>
            </Link>
          </div>

          <div className="bg-card text-card-foreground rounded-lg border shadow-sm p-6">
            <h2 className="text-xl font-semibold mb-4">Results</h2>
            <p className="text-muted-foreground mb-4">
              View election results and statistics after voting has concluded.
            </p>
            <Link href="/results">
              <Button variant="outline">View Results</Button>
            </Link>
          </div>
        </div>
      </main>

      <footer className="bg-muted p-4 text-center">
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} Election Management System. All rights reserved.
        </p>
      </footer>
    </div>
  )
}

